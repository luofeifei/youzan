package subscriber

func CoInit(body interface{}) (err error) {

	return nil
}